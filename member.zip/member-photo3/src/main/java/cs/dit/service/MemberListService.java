package cs.dit.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;

public class MemberListService implements MemberService {

   @Override
   public void execute(HttpServletRequest request, HttpServletResponse response) {
      //DB 연동
      System.out.println("listService 입니다!");
      
      MemberDAO dao = new MemberDAO();
      ArrayList<MemberDTO> dtos = dao.list();
      
      request.setAttribute("dtos", dtos);
      
   
      
   }

}
