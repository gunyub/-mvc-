package cs.dit.service;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;

public class MemberinsertService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pwd = request.getParameter("pwd");
		String photo = (String) request.getAttribute("photo");
		MemberDAO dao = new MemberDAO();
		MemberDTO dto = new MemberDTO(id, name, pwd, photo);
		dao.insert(dto);
		System.out.println(id);
		System.out.println(name);
		System.out.println(pwd);
		System.out.println(photo);
		
	
	

	}

}
